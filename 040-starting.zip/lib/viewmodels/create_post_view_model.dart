import 'package:compound/viewmodels/base_model.dart';

class CreatePostViewModel extends BaseModel {}
